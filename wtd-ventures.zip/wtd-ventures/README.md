# WTD Ventures — Acquisition Platform

A full-stack M&A research platform for acquiring established service businesses (HVAC, plumbing, electrical) across Oregon and SW Washington.

## Quick Start

```bash
# Install dependencies
npm install

# Start dev server
npm run dev

# Build for production
npm run build
```

Opens at `http://localhost:3000`

## Project Structure

```
wtd-ventures/
├── index.html              # Entry point with Google Fonts
├── package.json            # Dependencies (React, Vite, Lodash)
├── vite.config.js          # Vite configuration
└── src/
    ├── main.jsx            # React mount point
    ├── App.jsx             # Main app — header, tab navigation
    ├── data.js             # ★ TARGET DATABASE — no size limit
    ├── components.jsx      # Shared UI (Card, Sec, Row, OutreachCard, Logo)
    ├── BusinessPlanTab.jsx # Thesis, Value Creation, Portfolio, GTM
    ├── PipelineTab.jsx     # Target list, filters, detail panel
    ├── CompetitiveIntelTab.jsx # PE competitor profiles
    └── ResearchAgent.jsx   # AI-powered batch research agent
```

## Adding Targets

The `src/data.js` file contains the TARGETS array. There is **no size limit** — add as many targets as needed.

Each target follows this schema:

```javascript
{
  id: 81,                          // Unique ID
  company: "Example Heating",      // Full company name
  vertical: "HVAC",                // HVAC | Plumbing | Electrical | etc.
  location: "Portland, OR",        // City, State
  state: "OR",                     // OR | WA
  metro: "Portland Metro",         // Portland Metro | SW Washington | Salem / Willamette Valley | Eugene / Springfield | Bend / Central Oregon
  founded: 1965,                   // Year founded
  yearsInBusiness: 61,             // Current year - founded
  owners: "Name (Title)",          // Owner info. Use "Research needed" if unknown
  website: "https://...",          // Company website or "N/A"
  estRevenue: "$2M–$5M",          // Revenue range string
  estRevenueNum: 3500000,          // Midpoint number for sorting
  googleRating: 4.6,              // Google Business rating
  analogScore: 7,                  // 0-10 (10 = most analog = most upside)
  ccb: "12345",                    // Oregon CCB# or "Research needed"
  evaluation: "Investment thesis.", // 2-3 sentence assessment
  notes: "Key facts.",             // Short notes, max 120 chars
  tier: "A"                        // A | B | C
}
```

## Research Agent

The built-in AI Research Agent (`ResearchAgent.jsx`) uses the Anthropic API with web search to:

1. **Decompose** your request into parallel search queries
2. **Search** BBB, CCB, BuildZoom, Google, company websites in parallel
3. **Synthesize** results into structured target objects

### API Key

The agent calls `api.anthropic.com` directly from the browser. For production:

1. Create a `.env` file: `VITE_ANTHROPIC_API_KEY=sk-ant-...`
2. Update `ResearchAgent.jsx` to read `import.meta.env.VITE_ANTHROPIC_API_KEY`
3. Or proxy through a backend to avoid exposing the key

## Deployment

```bash
# Build static files
npm run build

# Deploy to Vercel
npx vercel

# Or deploy to Netlify
npx netlify deploy --prod --dir=dist
```

## Branding

- **Oregon Green**: #154733 (backgrounds), #1b8a5a (text/accents)
- **Oregon Yellow**: #FEE123 (highlights, active states)
- **Fonts**: Rajdhani (headers), Barlow (body), Barlow Condensed (labels)
- **Inspired by**: University of Oregon football / "Win The Day"
