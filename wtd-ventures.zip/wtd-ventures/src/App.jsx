import React, { useState } from "react";
import { Logo } from "./components";
import BusinessPlanTab from "./BusinessPlanTab";
import PipelineTab from "./PipelineTab";
import CompetitiveIntelTab from "./CompetitiveIntelTab";

export default function App() {
  const [tab, setTab] = useState("pipeline");

  const tabs = [
    { id: "plan", label: "BUSINESS PLAN", icon: "◆" },
    { id: "pipeline", label: "TARGET PIPELINE", icon: "◉" },
    { id: "intel", label: "COMPETITIVE INTEL", icon: "⚡" },
  ];

  return (
    <div style={{ fontFamily: "'Barlow',sans-serif", background: "#000", minHeight: "100vh", color: "#e0e0e0" }}>
      {/* HEADER */}
      <div style={{ background: "linear-gradient(180deg, #080808 0%, #000 100%)", borderBottom: "none", padding: "20px 24px 0" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12, marginBottom: 20 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <Logo />
            <div>
              <div style={{ fontFamily: "'Rajdhani',sans-serif", fontSize: 26, color: "#FEE123", fontWeight: 700, letterSpacing: 2, textTransform: "uppercase" }}>WTD Ventures</div>
              <div style={{ fontFamily: "'Barlow Condensed',sans-serif", fontSize: 11, color: "#1b8a5a", letterSpacing: 3, textTransform: "uppercase", fontWeight: 600 }}>Next Chapter Partners · Oregon & SW Washington</div>
            </div>
          </div>
        </div>
        {/* TAB BAR */}
        <div style={{ display: "flex", gap: 6 }}>
          {tabs.map(t => {
            const active = tab === t.id;
            return (
              <button key={t.id} onClick={() => setTab(t.id)} style={{
                background: active ? "linear-gradient(180deg, #154733, #0d2e22)" : "transparent",
                color: active ? "#FEE123" : "#555",
                border: active ? "1px solid #1b8a5a" : "1px solid transparent",
                borderBottom: active ? "1px solid #000" : "1px solid #1a1a1a",
                borderRadius: "8px 8px 0 0",
                padding: "12px 24px 10px",
                fontSize: 12,
                fontWeight: 700,
                fontFamily: "'Rajdhani',sans-serif",
                cursor: "pointer",
                letterSpacing: 2,
                transition: "all 0.2s",
                display: "flex",
                alignItems: "center",
                gap: 8,
                position: "relative",
              }}>
                <span style={{ fontSize: 10, opacity: active ? 1 : 0.4 }}>{t.icon}</span>
                {t.label}
                {active && <div style={{ position: "absolute", bottom: -1, left: 12, right: 12, height: 2, background: "#FEE123", borderRadius: 1 }} />}
              </button>
            );
          })}
          <div style={{ flex: 1, borderBottom: "1px solid #1a1a1a" }} />
        </div>
      </div>

      {/* TAB CONTENT */}
      {tab === "plan" && <BusinessPlanTab />}
      {tab === "pipeline" && <PipelineTab />}
      {tab === "intel" && <CompetitiveIntelTab />}
    </div>
  );
}
