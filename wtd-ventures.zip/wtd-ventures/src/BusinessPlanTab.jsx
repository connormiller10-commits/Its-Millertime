import React, { useState } from "react";
import { Card, OutreachCard, Sec, Row } from "./components";

export default function BusinessPlanTab() {
  const [planSection, setPlanSection] = useState("thesis");
  const sections = [
    { id: "thesis", label: "Thesis & Criteria" },
    { id: "playbook", label: "Value Creation" },
    { id: "portfolio", label: "Portfolio & Benchmarks" },
    { id: "sourcing", label: "GTM" },
  ];
  const sBtn = (id) => ({ background: planSection === id ? "linear-gradient(180deg, rgba(254,225,35,0.12), rgba(254,225,35,0.04))" : "#0a0a0a", color: planSection === id ? "#FEE123" : "#555", border: planSection === id ? "1px solid rgba(254,225,35,0.3)" : "1px solid #1a1a1a", borderRadius: 8, padding: "10px 18px", fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: "'Rajdhani',sans-serif", transition: "all 0.2s", letterSpacing: 1.5, textTransform: "uppercase" });

  return <div style={{ maxWidth: 960, margin: "0 auto", padding: "24px 24px 48px" }}>
    {/* Sub-nav */}
    <div style={{ display: "flex", gap: 8, marginBottom: 28, padding: "0 0 16px", borderBottom: "1px solid #1a1a1a", flexWrap: "nowrap", overflowX: "auto" }}>
      {sections.map(s => <button key={s.id} onClick={() => setPlanSection(s.id)} style={{ ...sBtn(s.id), whiteSpace: "nowrap", flex: "1 1 0" }}>{s.label}</button>)}
    </div>

    {/* ===== THESIS ===== */}
    {planSection === "thesis" && <>
      <div style={{ marginBottom: 32 }}>
        <div style={{ fontFamily: "'Barlow Condensed',sans-serif", fontSize: 12, color: "#1b8a5a", letterSpacing: 4, textTransform: "uppercase", fontWeight: 600, marginBottom: 8 }}>The Thesis</div>
        <div style={{ fontFamily: "'Rajdhani',sans-serif", fontSize: 30, color: "#FEE123", fontWeight: 700, letterSpacing: 1, textTransform: "uppercase", lineHeight: 1.2, marginBottom: 12 }}>Build a regional portfolio of essential, non-discretionary service businesses</div>
        <div style={{ fontSize: 15, color: "#999", lineHeight: 1.8, maxWidth: 700 }}>Companies that homeowners and commercial property managers cannot defer indefinitely. The strategy: acquire established, analog-operated companies with strong reputations, then modernize operations, cross-sell across verticals, and create economies of scale that no standalone operator can match.</div>
      </div>

      {/* Three pillars */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16, marginBottom: 32 }}>
        {[
          { icon: "01", title: "Acquire", desc: "Source off-market deals from retiring owners. Asset purchases, SBA 7(a)...", color: "#FEE123" },
          { icon: "02", title: "Modernize", desc: "Deploy ServiceTitan, AI-powered marketing, route optimization. Unlock 8-15%...", color: "#1b8a5a" },
          { icon: "03", title: "Scale", desc: "Cross-sell across verticals, centralize back office, convert to recurring...", color: "#FEE123" },
        ].map((p, i) => (
          <div key={i} style={{ background: "#0a0a0a", border: "1px solid #1a1a1a", borderRadius: 12, padding: 24, borderTop: `3px solid ${p.color}` }}>
            <div style={{ fontSize: 36, color: p.color, fontWeight: 800, opacity: 0.3, marginBottom: 8 }}>{p.icon}</div>
            <div style={{ fontFamily: "'Rajdhani',sans-serif", fontSize: 20, color: "#fff", fontWeight: 700, letterSpacing: 0.5, marginBottom: 8 }}>{p.title}</div>
            <div style={{ fontSize: 13, color: "#888", lineHeight: 1.7 }}>{p.desc}</div>
          </div>
        ))}
      </div>

      {/* Key metrics */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 32 }}>
        {[
          { v: "$2M–$12M", l: "Revenue Sweet Spot", c: "#FEE123" },
          { v: "10+ yrs", l: "Operating History", c: "#1b8a5a" },
          { v: "4.0+", l: "Min Google Stars", c: "#FEE123" },
          { v: "55+", l: "Ideal Owner Age", c: "#1b8a5a" },
        ].map((m, i) => (
          <div key={i} style={{ background: "#0a0a0a", border: "1px solid #1a1a1a", borderRadius: 10, padding: "16px 12px", textAlign: "center" }}>
            <div style={{ fontSize: 24, color: m.c, fontWeight: 800 }}>{m.v}</div>
            <div style={{ fontSize: 10, color: "#666", fontWeight: 600, letterSpacing: 0.5, marginTop: 4 }}>{m.l}</div>
          </div>
        ))}
      </div>

      {/* Why this works */}
      <Card accent="#154733">
        <div style={{ fontFamily: "'Rajdhani',sans-serif", fontSize: 17, color: "#1b8a5a", fontWeight: 700, letterSpacing: 0.5, marginBottom: 16 }}>Why Home Services Roll-Ups Work</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
          {[
            { title: "Recession-Resistant Demand", desc: "Broken furnaces, burst pipes, and failed circuits don't wait for economic..." },
            { title: "Fragmented Market", desc: "90% of home service companies have under $5M in revenue. No dominant player..." },
            { title: "Aging Owner Demographics", desc: "Average trade business owner is 58 years old. 65% have no succession plan...." },
            { title: "Massive Modernization Gap", desc: "Most companies still run on paper tickets and spreadsheets. Deploying..." },
          ].map((item, i) => <div key={i}>
            <div style={{ fontSize: 13, color: "#FEE123", fontWeight: 600, marginBottom: 4 }}>{item.title}</div>
            <div style={{ fontSize: 12, color: "#888", lineHeight: 1.7 }}>{item.desc}</div>
          </div>)}
        </div>
      </Card>

      {/* --- TARGET CRITERIA (merged into Thesis) --- */}
      <div style={{ marginTop: 36, paddingTop: 32, borderTop: "2px solid #1a1a1a" }}>
        <div style={{ fontFamily: "'Barlow Condensed',sans-serif", fontSize: 12, color: "#1b8a5a", letterSpacing: 4, textTransform: "uppercase", fontWeight: 600, marginBottom: 8 }}>Target Profile</div>
        <div style={{ fontFamily: "'Rajdhani',sans-serif", fontSize: 22, color: "#FEE123", fontWeight: 700, letterSpacing: 1, marginBottom: 24 }}>What We're Looking For</div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 24 }}>
        {[
          { label: "Industry Verticals", value: "HVAC, Electrical, Plumbing, Fire Protection, Roofing, Pest Control, Landscaping,...", icon: "🔧" },
          { label: "Operating History", value: "10+ years continuous operation under current or prior ownership. Longer = more brand...", icon: "📅" },
          { label: "Revenue Range", value: "$1M – $30M annual revenue. Sweet spot: $2M – $12M. Sub-$5M eligible for SBA 7(a). $5M+...", icon: "💰" },
          { label: "Geography", value: "Oregon & SW Washington. Portland metro primary. Salem, Eugene, Vancouver WA, Bend as...", icon: "📍" },
          { label: "Workforce", value: "10 – 150 W-2 employees. Avoid 1099-heavy models unless converting to W-2 is feasible....", icon: "👷" },
          { label: "Customer Base", value: "Mix of residential and light commercial preferred. Pure commercial acceptable if...", icon: "🏠" },
          { label: "Reputation", value: "4.0+ Google stars with 100+ reviews. BBB accredited or equivalent. Minimal...", icon: "⭐" },
          { label: "Analog Score", value: "HIGH preferred. Paper tickets, spreadsheets, legacy QuickBooks, no CRM, no...", icon: "📋" },
        ].map((item, i) => (
          <div key={i} style={{ background: "#0a0a0a", border: "1px solid #1a1a1a", borderRadius: 10, padding: 20 }}>
            <div style={{ fontSize: 24, marginBottom: 8 }}>{item.icon}</div>
            <div style={{ fontSize: 14, color: "#FEE123", fontWeight: 700, marginBottom: 6 }}>{item.label}</div>
            <div style={{ fontSize: 12, color: "#888", lineHeight: 1.7 }}>{item.value}</div>
          </div>
        ))}
      </div>

      <Card accent="#FEE123">
        <div style={{ fontFamily: "'Rajdhani',sans-serif", fontSize: 17, color: "#FEE123", fontWeight: 700, letterSpacing: 0.5, marginBottom: 12 }}>Ideal Owner Profile — Highest-Probability Sellers</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16 }}>
          {[
            { signal: "Age 55+", desc: "Founder-operated, approaching retirement, no energy for another growth cycle" },
            { signal: "No Succession Plan", desc: "No family members in the business, no internal candidate groomed for leadership" },
            { signal: "Life Event", desc: "Estate planning, divorce, partnership dissolution, health concerns, burnout" },
            { signal: "Stale Digital Presence", desc: "Website copyright 3+ years old, no social media posts in 12+ months, no..." },
            { signal: "Coasting Operations", desc: "Steady revenue but no growth. No new hires. No marketing. Business runs..." },
            { signal: "Technology Gap", desc: "No online booking, no CRM, Craigslist job postings, 'call for estimate'..." },
          ].map((s, i) => <div key={i} style={{ padding: "12px 0", borderBottom: i < 5 ? "1px solid #1a1a1a" : "none" }}>
            <div style={{ fontSize: 13, color: "#FEE123", fontWeight: 600, marginBottom: 2 }}>{s.signal}</div>
            <div style={{ fontSize: 11, color: "#777", lineHeight: 1.6 }}>{s.desc}</div>
          </div>)}
        </div>
      </Card>

      <Card accent="#1b8a5a">
        <div style={{ fontFamily: "'Rajdhani',sans-serif", fontSize: 17, color: "#1b8a5a", fontWeight: 700, letterSpacing: 0.5, marginBottom: 12 }}>Deal Structure</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
          {[
            ["Structure", "Asset purchases preferred — avoid inheriting unknown liabilities"],
            ["Financing", "SBA 7(a) for sub-$5M deals. Private capital + seller financing for larger transactions"],
            ["Seller Financing", "10–20% earnout tied to transition milestones. Aligns incentives during handoff"],
            ["Transition Period", "6–12 month owner consulting agreement. Knowledge transfer is the #1 risk to manage"],
            ["Sub-$5M Multiples", "2.5x – 4.5x SDE (Seller's Discretionary Earnings)"],
            ["$5M+ Multiples", "4x – 6x EBITDA. Platform premium for businesses that can anchor a vertical"],
            ["RE Priority", "Businesses owning their facility are prioritized — SBA collateral, sale-leaseback optionality, hub potential"],
            ["Key Diligence", "Customer concentration, workforce stability, fleet condition, environmental liability (refrigerants, asbestos)"],
          ].map(([k, v], i) => <div key={i}>
            <div style={{ fontSize: 12, color: "#FEE123", fontWeight: 600 }}>{k}</div>
            <div style={{ fontSize: 12, color: "#888", lineHeight: 1.6 }}>{v}</div>
          </div>)}
        </div>
      </Card>
    </>}

    {/* ===== VALUE CREATION PLAYBOOK ===== */}
    {planSection === "playbook" && <>
      <div style={{ fontFamily: "'Barlow Condensed',sans-serif", fontSize: 12, color: "#1b8a5a", letterSpacing: 4, textTransform: "uppercase", fontWeight: 600, marginBottom: 8 }}>Value Creation</div>
      <div style={{ fontFamily: "'Rajdhani',sans-serif", fontSize: 26, color: "#FEE123", fontWeight: 700, letterSpacing: 1, marginBottom: 8 }}>The Modernization Playbook</div>
      <div style={{ fontSize: 14, color: "#888", lineHeight: 1.7, marginBottom: 28, maxWidth: 700 }}>Every acquired company runs through the same value creation framework. The analog score determines where we start — higher analog = more levers to pull = more upside.</div>

      {[
        { title: "Operational Modernization", impact: "8–15% EBITDA improvement", timeline: "90 days", color: "#FEE123",
          details: "Deploy ServiceTitan or Housecall Pro for dispatching, invoicing, and CRM. Implement route optimization (saves 15-20% on fuel and windshield time). Automated appointment reminders reduce no-shows by 30%. Real-time technician tracking improves dispatch efficiency. Digital invoicing cuts A/R days from 30+ to same-day." },
        { title: "Cross-Selling Engine", impact: "15–25% revenue uplift", timeline: "6 months", color: "#1b8a5a",
          details: "An HVAC customer also needs electrical, plumbing, and pest control. Each additional vertical added to a household drops customer acquisition cost toward zero. A customer who called for a furnace repair gets a plumbing inspection upsell. Shared customer database across all portfolio companies enables automated cross-sell campaigns." },
        { title: "Shared Back Office", impact: "12–18% overhead reduction", timeline: "120 days", color: "#FEE123",
          details: "Centralize bookkeeping, HR/payroll, fleet management, insurance, procurement (volume discounts on parts/materials), call center, and marketing across all portfolio companies. A single AP/AR team, one insurance broker, one fleet manager. Procurement leverage: 15-25% discount on equipment and parts at scale." },
        { title: "Brand Arbitrage", impact: "Preserved goodwill + scale leverage", timeline: "Ongoing", color: "#1b8a5a",
          details: "Keep every local brand name and customer-facing identity. A 70-year-old plumbing company's name is worth more than any holding company brand. Consolidate under WTD Ventures only for financing, procurement, and back-office. Customers never know. Employees keep their identity. But vendors see a $30M+ combined entity." },
        { title: "Recurring Revenue Conversion", impact: "Highest-value lever in home services", timeline: "6–12 months", color: "#FEE123",
          details: "Convert one-time repair customers to annual maintenance agreements (AMAs). An HVAC tune-up agreement at $199/year × 5,000 customers = $1M predictable revenue. AMAs increase customer lifetime value 3-5x, reduce churn, smooth seasonal revenue, and create a predictable cash flow stream that dramatically increases business valuation." },
        { title: "Technician Recruitment & Retention", impact: "Reduced turnover, expanded capacity", timeline: "Ongoing", color: "#1b8a5a",
          details: "Offer career ladders, health benefits, 401(k), paid training, and cross-trade mobility that a standalone $4M shop cannot. Technicians can move from HVAC to electrical to plumbing within the portfolio. Apprenticeship programs feed the pipeline. Competitive compensation benchmarking across the portfolio ensures market-rate pay." },
        { title: "AI-Powered Operations", impact: "Next-gen competitive moat", timeline: "12 months", color: "#FEE123",
          details: "No competitor is deploying AI at the local level. Implement AI for: call routing and sentiment analysis, demand forecasting (predict breakdown calls before they happen), dynamic pricing optimization, automated review management and response, AI-generated marketing content, lead scoring and nurture sequences, predictive maintenance scheduling." },
      ].map((item, i) => (
        <div key={i} style={{ background: "#0a0a0a", border: "1px solid #1a1a1a", borderRadius: 12, padding: 24, marginBottom: 12, borderLeft: `3px solid ${item.color}` }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
            <div>
              <div style={{ fontFamily: "'Rajdhani',sans-serif", fontSize: 20, color: "#fff", fontWeight: 700, letterSpacing: 0.5, marginBottom: 4 }}>{item.title}</div>
              <div style={{ display: "flex", gap: 12 }}>
                <span style={{ fontSize: 11, color: "#FEE123", background: "rgba(254,225,35,0.1)", padding: "3px 10px", borderRadius: 4, fontWeight: 600 }}>{item.impact}</span>
                <span style={{ fontSize: 11, color: "#888", background: "rgba(255,255,255,0.05)", padding: "3px 10px", borderRadius: 4 }}>Timeline: {item.timeline}</span>
              </div>
            </div>
            <div style={{ fontSize: 28, color: item.color, fontWeight: 800, opacity: 0.2 }}>0{i + 1}</div>
          </div>
          <div style={{ fontSize: 13, color: "#999", lineHeight: 1.8 }}>{item.details}</div>
        </div>
      ))}
    </>}

    {/* ===== DEAL SOURCING METHODOLOGY ===== */}
    {planSection === "sourcing" && <>
      <div style={{ fontFamily: "'Barlow Condensed',sans-serif", fontSize: 12, color: "#1b8a5a", letterSpacing: 4, textTransform: "uppercase", fontWeight: 600, marginBottom: 8 }}>Research Methodology</div>
      <div style={{ fontFamily: "'Rajdhani',sans-serif", fontSize: 26, color: "#FEE123", fontWeight: 700, letterSpacing: 1, marginBottom: 24 }}>Three-Phase Deal Sourcing</div>

      {[
        { phase: "Phase 1", title: "Active Listings", desc: "Businesses explicitly for sale", color: "#FEE123", items: [
          { name: "Business-for-Sale Marketplaces", detail: "BizBuySell, BizQuest, BusinessBroker.net, LoopNet, DealStream (formerly MergerNetwork), Axial.net (lower middle market)" },
          { name: "Franchise Resales", detail: "Mr. Electric, One Hour Heating & Air, Benjamin Franklin Plumbing, Neighborly brands, Home Franchise Concepts — resale units come with built-in SOPs" },
          { name: "SBA Loan Data", detail: "SBA loan databases indicate businesses that took acquisition loans — signals a prior sale and possible re-sale cycle" },
          { name: "Broker Networks", detail: "M&A brokers specializing in home services and trades in Portland/OR/WA. Get on buyer lists for every broker in market." },
        ]},
        { phase: "Phase 2", title: "Off-Market Prospecting", desc: "This is where the alpha is — most of the best acquisitions are never listed", color: "#1b8a5a", items: [
          { name: "Owner Age & Succession Signals", detail: "Cross-reference state SOS filings with LinkedIn. Owners 55+ with no family in the business. Same registered agent for 15+ years." },
          { name: "Stale Digital Presence", detail: "Old WordPress themes, copyright footer dated 3+ years ago, no social media in 12+ months, steady reviews but owner has checked out on growth." },
          { name: "Technology Gap Signals", detail: "'Call for estimate' only (no online booking), no CRM, Craigslist job postings, no fleet GPS/tracking visible, check-only payments." },
          { name: "State Licensing Databases", detail: "Oregon CCB, WA L&I — filter for licenses issued 10+ years ago, active status, cross-reference with owner name and age." },
          { name: "Review Mining", detail: "Google, Yelp, BBB, Angi — look for reviews mentioning long tenure ('been using them 15 years'), quality praise, but also scheduling/communication complaints (signal of ops breakdown = modernization opportunity)." },
          { name: "Competitive Density Mapping", detail: "Identify MSAs with fragmented competition (many small operators, no dominant player). These are ideal roll-up geographies." },
        ]},
        { phase: "Phase 3", title: "Deep Qualification", desc: "Investment-grade intelligence on every qualified candidate", color: "#FEE123", items: [
          { name: "Financial Estimation", detail: "Employee count (LinkedIn, job postings), fleet size (Google Maps satellite), industry benchmarks (ACCA, PHCC, IEC). Cross-reference Inc. 5000, local biz journals." },
          { name: "Legal & Regulatory", detail: "State court records, OSHA violations, EPA enforcement, BBB complaints, state AG consumer complaints, active lawsuits." },
          { name: "Workforce Stability", detail: "Glassdoor/Indeed reviews, average tenure (LinkedIn), job posting velocity (turnover vs. growth — disambiguate)." },
          { name: "Customer Concentration", detail: "Revenue spread across many small customers (ideal) vs. concentrated in few large contracts (risky unless multi-year with renewal)." },
          { name: "Real Estate Ownership", detail: "County assessor records. Own = additional asset value + SBA collateral + sale-leaseback optionality. Lease = check term and transferability." },
          { name: "Fleet & Equipment", detail: "Visible fleet size and condition (Google Maps, Facebook photos). Branded vs. unbranded vehicles (branded = stronger local brand equity)." },
        ]},
      ].map((phase, pi) => (
        <div key={pi} style={{ marginBottom: 24 }}>
          <div style={{ display: "flex", gap: 12, alignItems: "center", marginBottom: 16 }}>
            <div style={{ width: 48, height: 48, borderRadius: 10, background: phase.color === "#FEE123" ? "rgba(254,225,35,0.1)" : "rgba(21,71,51,0.3)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, color: phase.color, fontWeight: 800, border: `1px solid ${phase.color}40` }}>{phase.phase.split(" ")[1]}</div>
            <div>
              <div style={{ fontFamily: "'Rajdhani',sans-serif", fontSize: 20, color: "#fff", fontWeight: 700, letterSpacing: 0.5 }}>{phase.title}</div>
              <div style={{ fontSize: 12, color: "#888" }}>{phase.desc}</div>
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginLeft: 60 }}>
            {phase.items.map((item, i) => (
              <div key={i} style={{ background: "#0a0a0a", border: "1px solid #1a1a1a", borderRadius: 8, padding: 14 }}>
                <div style={{ fontSize: 12, color: phase.color, fontWeight: 600, marginBottom: 4 }}>{item.name}</div>
                <div style={{ fontSize: 11, color: "#777", lineHeight: 1.6 }}>{item.detail}</div>
              </div>
            ))}
          </div>
        </div>
      ))}

      {/* --- OUTREACH TEMPLATES (merged into GTM) --- */}
      <div style={{ marginTop: 32, paddingTop: 28, borderTop: "2px solid #1a1a1a" }}>
        <div style={{ fontFamily: "'Barlow Condensed',sans-serif", fontSize: 12, color: "#1b8a5a", letterSpacing: 4, textTransform: "uppercase", fontWeight: 600, marginBottom: 8 }}>Outreach Templates</div>
        <div style={{ fontFamily: "'Rajdhani',sans-serif", fontSize: 22, color: "#FEE123", fontWeight: 700, letterSpacing: 1, marginBottom: 8 }}>Communication Playbook</div>
        <div style={{ fontSize: 14, color: "#888", lineHeight: 1.7, marginBottom: 24, maxWidth: 700 }}>Confidentiality is paramount. Never reveal the full roll-up strategy. Position initial contact as "exploring strategic partnership opportunities."</div>
      </div>

      <OutreachCard
        title="Direct Mail — Owner-to-Owner Letter"
        subtitle="Handwritten envelope, personal letterhead. Highest-converting outreach method."
        badge="HIGHEST CONVERSION"
        accent="#FEE123"
        casual={"[Owner First Name] —\n...\n\n[Your Name]\n[Phone]"}
        pe={"Dear [Owner First Name],\n\nOn behalf of WTD Ventures, I'm writing to express our interest in exploring a potential strategic partnership with [Company Name]. We are a Portland-based investment firm focused exclusively on acquiring and growing premier home services brands in the Pacific Northwest.\n...\n\nRespectfully,\n[Your Name]\nWTD Ventures"}
        local={"Dear [Owner First Name],\n\nOur team grew up watching companies like [Company Name] take care of families in this community. What you've built over [XX] years — the reputation, the trust, the team — that doesn't happen by accident. It happens because you showed up every single day and did the work.\n...\n\n[Your Name]\nWTD Ventures"}
      />

      <OutreachCard
        title="Broker Outreach Email"
        subtitle="Get on every broker's buyer list in the Portland/OR/WA market."
        accent="#1b8a5a"
        casual={"Subject: Looking for home services deals in Portland\n\nHey [Broker Name] —\n...\n\n[Your Name]\n[Phone]"}
        pe={"Subject: Acquisition Criteria — Residential & Commercial Services, Portland MSA\n\nDear [Broker Name],\n\nWTD Ventures is a Portland-based acquisition firm actively seeking established home services companies in the Oregon and SW Washington markets. We are currently evaluating opportunities that meet the following investment criteria:\n...\n\nRespectfully,\n[Your Name]\nWTD Ventures"}
        local={"Subject: Portland-based team looking for the right home services business\n\nHi [Broker Name],\n...\n\n[Your Name]\nWTD Ventures"}
      />

      <Card accent="#FEE123">
        <div style={{ fontFamily: "'Rajdhani',sans-serif", fontSize: 17, color: "#FEE123", fontWeight: 700, letterSpacing: 0.5, marginBottom: 12 }}>Key Outreach Principles</div>
        {[
          { rule: "Lead with admiration, not ambition", desc: "The owner built this business over decades. Lead with genuine respect for..." },
          { rule: "Differentiate from PE immediately", desc: "'I'm not a private equity fund or a tire-kicker.' Every owner has been..." },
          { rule: "Coffee, not contracts", desc: "First meeting is just coffee. No LOI, no financials, no due diligence. Two..." },
          { rule: "Never reveal the roll-up", desc: "Position as 'exploring opportunities to acquire and invest in one or two..." },
          { rule: "Follow up without pressure", desc: "No response? Handwritten note 3 weeks later. Holiday card. Another letter 6..." },
        ].map((item, i) => <div key={i} style={{ padding: "10px 0", borderBottom: i < 4 ? "1px solid #111" : "none" }}>
          <div style={{ fontSize: 13, color: "#FEE123", fontWeight: 600, marginBottom: 2 }}>{item.rule}</div>
          <div style={{ fontSize: 12, color: "#888", lineHeight: 1.7 }}>{item.desc}</div>
        </div>)}
      </Card>
    </>}

    {/* ===== PORTFOLIO & BENCHMARKS ===== */}
    {planSection === "portfolio" && <>
      <div style={{ fontFamily: "'Rajdhani',sans-serif", fontSize: 22, color: "#FEE123", fontWeight: 700, letterSpacing: 1, marginBottom: 16 }}>Portfolio Strategy & Benchmarks</div>
      <Card accent="#FEE123">
        <div style={{ fontFamily: "'Rajdhani',sans-serif", fontSize: 16, color: "#FEE123", fontWeight: 700, marginBottom: 8 }}>Cross-Sell Revenue Matrix</div>
        <div style={{ fontSize: 12, color: "#888", lineHeight: 1.8 }}>Every HVAC customer is a warm lead for plumbing and electrical. Industry benchmark: 15-25% revenue uplift from cross-selling adjacent services.</div>
      </Card>
      <Card accent="#1b8a5a">
        <div style={{ fontFamily: "'Rajdhani',sans-serif", fontSize: 16, color: "#1b8a5a", fontWeight: 700, marginBottom: 8 }}>Key Benchmarks — Residential</div>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 11 }}>
            <thead><tr>{["KPI", "Best in Class", "Average", "Red Flag"].map((h, i) => <th key={i} style={{ padding: "8px", textAlign: "left", color: i === 0 ? "#888" : "#FEE123", borderBottom: "1px solid #1a1a1a" }}>{h}</th>)}</tr></thead>
            <tbody>{[
              ["Gross Margin", "50–60%", "40–50%", "Below 35%"],
              ["EBITDA Margin", "15–25%", "8–12%", "Below 5%"],
              ["Maintenance Agreement Rate", "30–50%", "10–20%", "Below 5%"],
              ["Customer Retention (2yr)", "50–70%", "40–50%", "Below 30%"],
              ["Avg Ticket Size", "$450–$800+", "$300–$450", "Below $250"],
              ["First-Time Fix Rate", "85–95%", "70–85%", "Below 65%"],
            ].map((row, ri) => <tr key={ri}>{row.map((cell, ci) => <td key={ci} style={{ padding: "6px 8px", color: ci === 0 ? "#ccc" : ci === 3 ? "#8B2500" : "#888", borderBottom: "1px solid #111" }}>{cell}</td>)}</tr>)}</tbody>
          </table>
        </div>
      </Card>
      <Card accent="#FEE123">
        <div style={{ fontFamily: "'Rajdhani',sans-serif", fontSize: 16, color: "#FEE123", fontWeight: 700, marginBottom: 8 }}>Investment Verdict</div>
        <div style={{ fontSize: 13, color: "#ccc", lineHeight: 1.8 }}>Residential wins as the primary target. Higher margins, lower customer concentration risk, massive cross-sell potential, and a defensive competitive moat. Commercial is a strategic add-on for portfolio companies that already have commercial contracts.</div>
      </Card>
    </>}

  </div>;
}
