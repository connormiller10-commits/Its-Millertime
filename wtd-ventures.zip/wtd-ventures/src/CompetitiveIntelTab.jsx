import React, { useState } from "react";
import { COMPETITORS } from "./data";
import { Card, Sec, Row } from "./components";

export default function CompetitiveIntelTab() {
  const [selected, setSelected] = useState(null);
  const peTargets = TARGETS.filter(t => t.notes && (t.notes.includes("PE-ACQUIRED") || t.notes.includes("COMPETITOR") || t.notes.includes("SEER Group")));

  return <div style={{ maxWidth: 1000, margin: "0 auto", padding: "32px 24px" }}>
    <div style={{ marginBottom: 32 }}>
      <div style={{ fontFamily: "'Rajdhani',sans-serif", fontSize: 30, color: "#FEE123", fontWeight: 700, letterSpacing: 1, textTransform: "uppercase", marginBottom: 4 }}>Competitive Intelligence</div>
      <div style={{ fontSize: 14, color: "#888", lineHeight: 1.7 }}>Three PE-backed or self-funded roll-up competitors are actively acquiring home services businesses in the Portland/OR/WA market. Understanding their playbooks is critical to winning deals against them.</div>
    </div>

    <div style={{ display: "flex", gap: 16, marginBottom: 32, flexWrap: "wrap" }}>
      {[
        { label: "Active Competitors", value: "3", color: "#8B2500" },
        { label: "Portland Brands Acquired", value: peTargets.length, color: "#FEE123" },
        { label: "Combined Employee Base", value: "9,000+", color: "#fff" },
        { label: "Combined Capital", value: "$6B+", color: "#1b8a5a" },
      ].map((s, i) => (
        <div key={i} style={{ background: "#0a0a0a", border: "1px solid #1a1a1a", borderRadius: 10, padding: "16px 24px", flex: "1 1 140px", textAlign: "center" }}>
          <div style={{ fontSize: 28, color: s.color, fontWeight: 800 }}>{s.value}</div>
          <div style={{ fontSize: 10, color: "#666", fontWeight: 600, letterSpacing: 0.5 }}>{s.label}</div>
        </div>
      ))}
    </div>

    {COMPETITORS.map(c => (
      <div key={c.id} style={{ background: "#0a0a0a", border: "1px solid #1a1a1a", borderRadius: 10, marginBottom: 16, borderLeft: `3px solid ${c.color}`, overflow: "hidden" }}>
        <div onClick={() => setSelected(selected === c.id ? null : c.id)} style={{ padding: 20, cursor: "pointer", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ fontFamily: "'Rajdhani',sans-serif", fontSize: 20, color: "#fff", fontWeight: 700, letterSpacing: 0.5 }}>{c.name}</div>
            <div style={{ fontSize: 12, color: "#888" }}>{c.hq} · Founded {c.founded} · {c.backer}</div>
          </div>
          <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
            <span style={{ fontSize: 10, fontWeight: 700, color: c.threat.includes("VERY HIGH") ? "#FEE123" : c.threat.includes("HIGH") ? "#ff6b47" : "#888", background: "rgba(255,255,255,0.05)", padding: "4px 10px", borderRadius: 4 }}>THREAT: {c.threat.split("—")[0].trim()}</span>
            <span style={{ color: "#555", fontSize: 18 }}>{selected === c.id ? "▾" : "▸"}</span>
          </div>
        </div>

        {selected === c.id && (
          <div style={{ padding: "0 20px 20px", borderTop: "1px solid #1a1a1a" }}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginTop: 16 }}>
              <div>
                <Sec title="Overview" color={c.color}>
                  <Row l="CEO" v={c.ceo} />
                  <Row l="Funding" v={c.funding} />
                  <Row l="Employees" v={c.employees} />
                  <Row l="Brands" v={c.brands} />
                  <Row l="Website" v={c.website} />
                </Sec>
              </div>
              <div>
                <Sec title="Strategy" color={c.color}>
                  <div style={{ fontSize: 12, color: "#999", lineHeight: 1.7 }}>{c.strategy}</div>
                </Sec>
              </div>
            </div>

            <Sec title="Portland / OR / WA Brands Acquired" color="#FEE123">
              {c.localBrands.map((b, i) => <div key={i} style={{ fontSize: 13, color: "#FEE123", padding: "4px 0", borderBottom: "1px solid #1a1a1a" }}>● {b}</div>)}
            </Sec>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
              <Sec title="Strengths" color="#1b8a5a">
                <div style={{ fontSize: 12, color: "#8fdfb4", lineHeight: 1.7 }}>{c.strengths}</div>
              </Sec>
              <Sec title="Weaknesses" color="#8B2500">
                <div style={{ fontSize: 12, color: "#ff6b47", lineHeight: 1.7 }}>{c.weaknesses}</div>
              </Sec>
            </div>

            <Sec title="Threat Assessment" color="#FEE123">
              <div style={{ fontSize: 13, color: "#ccc", lineHeight: 1.7 }}>{c.threat}</div>
            </Sec>
          </div>
        )}
      </div>
    ))}

    <Card accent="#FEE123">
      <div style={{ fontFamily: "'Rajdhani',sans-serif", fontSize: 17, color: "#FEE123", fontWeight: 700, letterSpacing: 0.5, marginBottom: 12 }}>WTD Ventures Competitive Advantages</div>
      {[
        { title: "Local Presence", desc: "Based in Portland, OR. A team of Oregon operators, finance professionals,..." },
        { title: "Speed & Flexibility", desc: "No investment committee approvals. No fund timeline pressure. We can move..." },
        { title: "AI-Powered Operations", desc: "No other competitor is deploying AI for call routing, demand forecasting,..." },
        { title: "Founder-to-Founder", desc: "We're not sending a VP of Corp Dev. Connor and his partner sit across the..." },
        { title: "Not PE", desc: "Every owner has heard horror stories about PE acquisitions — price..." },
        { title: "Cross-Vertical from Day 1", desc: "We're building HVAC + Electrical + Plumbing from the start. SEER started HVAC-only and is just now adding plumbing. We design the portfolio for cross-sell from acquisition #1." },
      ].map((item, i) => <div key={i} style={{ marginBottom: 12 }}>
        <div style={{ fontSize: 13, color: "#FEE123", fontWeight: 600 }}>{item.title}</div>
        <div style={{ fontSize: 12, color: "#888", lineHeight: 1.6 }}>{item.desc}</div>
      </div>)}
    </Card>
  </div>;
}

// ==================== MAIN APP ====================
