import React, { useState, useMemo } from "react";
import _ from "lodash";
import { TARGETS, VERTICALS, METROS, TIERS, tierColor } from "./data";
import { Card, Sec, Row } from "./components";
import ResearchAgent from "./ResearchAgent";

export default function PipelineTab() {
  const [filters, setFilters] = useState({ vertical: "All", metro: "All", tier: "All", searchText: "" });
  const [selectedTarget, setSelectedTarget] = useState(null);
  const [sortBy, setSortBy] = useState("tier");
  const [showAgent, setShowAgent] = useState(false);
  const [agentMessages, setAgentMessages] = useState([]);
  const [agentInput, setAgentInput] = useState("");
  const [agentLoading, setAgentLoading] = useState(false);
  const [agentProgress, setAgentProgress] = useState(null);

  const filtered = useMemo(() => {
    let r = TARGETS.filter(t => {
      if (filters.vertical !== "All" && t.vertical !== filters.vertical) return false;
      if (filters.metro !== "All" && t.metro !== filters.metro) return false;
      if (filters.tier !== "All" && t.tier !== filters.tier) return false;
      if (filters.searchText) {
        const s = filters.searchText.toLowerCase();
        return t.company.toLowerCase().includes(s) || t.location.toLowerCase().includes(s) || t.vertical.toLowerCase().includes(s) || t.owners.toLowerCase().includes(s) || t.notes.toLowerCase().includes(s);
      }
      return true;
    });
    if (sortBy === "tier") r = _.orderBy(r, ["tier", "yearsInBusiness"], ["asc", "desc"]);
    else if (sortBy === "revenue") r = _.orderBy(r, "estRevenueNum", "desc");
    else if (sortBy === "years") r = _.orderBy(r, "yearsInBusiness", "desc");
    else if (sortBy === "analog") r = _.orderBy(r, "analogScore", "desc");
    return r;
  }, [filters, sortBy]);

  const stats = useMemo(() => ({
    total: TARGETS.length,
    tierA: TARGETS.filter(t => t.tier === "A").length,
    avgAnalog: (TARGETS.reduce((a, t) => a + t.analogScore, 0) / TARGETS.length).toFixed(1),
  }), []);

  const sel = { background: "#111", border: "1px solid #2a2a2a", borderRadius: 6, color: "#e0e0e0", padding: "8px 12px", fontSize: 13, fontFamily: "'Barlow',sans-serif", cursor: "pointer", outline: "none", minWidth: 120 };
  const F = ({ label, children }) => <div style={{ display: "flex", flexDirection: "column", gap: 4 }}><span style={{ fontSize: 10, letterSpacing: 1.5, textTransform: "uppercase", color: "#777", fontWeight: 600 }}>{label}</span>{children}</div>;



  return <div>
    <div style={{ padding: "16px 24px", display: "flex", gap: 28, flexWrap: "wrap", alignItems: "center" }}>
      {[{ v: stats.total, l: "Total Targets", c: "#fff" }, { v: stats.tierA, l: "Tier A", c: "#FEE123" }, { v: stats.avgAnalog + "/10", l: "Avg Analog", c: "#fff" }].map((s, i) => (
        <div key={i} style={{ textAlign: "center" }}>
          <div style={{ fontSize: 24, color: s.c, fontWeight: 800 }}>{s.v}</div>
          <div style={{ fontSize: 10, color: "#666", fontWeight: 600, letterSpacing: 0.5 }}>{s.l}</div>
        </div>
      ))}
      <div style={{ flex: 1 }} />
      <button onClick={() => setShowAgent(!showAgent)} style={{
        background: showAgent ? "linear-gradient(180deg, #1b8a5a, #154733)" : "linear-gradient(180deg, #154733, #0d2e22)",
        color: "#FEE123",
        border: "1px solid #1b8a5a",
        borderRadius: 8, padding: "10px 20px", fontSize: 12, fontWeight: 700,
        fontFamily: "'Rajdhani',sans-serif", cursor: "pointer", letterSpacing: 1.5,
        textTransform: "uppercase", display: "flex", alignItems: "center", gap: 8, transition: "all 0.2s"
      }}>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
        Research Agent
      </button>
    </div>

    {showAgent && <ResearchAgent onTargetsFound={(t) => console.log("New targets:", t)} />}



    <div style={{ padding: "8px 24px 12px", borderBottom: "1px solid #1a1a1a", display: "flex", gap: 12, flexWrap: "wrap", alignItems: "flex-end" }}>
      <F label="Search"><input type="text" placeholder="Company, owner, keyword..." value={filters.searchText} onChange={e => setFilters(p => ({ ...p, searchText: e.target.value }))} style={{ ...sel, minWidth: 200 }} /></F>
      <F label="Vertical"><select value={filters.vertical} onChange={e => setFilters(p => ({ ...p, vertical: e.target.value }))} style={sel}><option value="All">All</option>{VERTICALS.map(v => <option key={v}>{v}</option>)}</select></F>
      <F label="Metro"><select value={filters.metro} onChange={e => setFilters(p => ({ ...p, metro: e.target.value }))} style={sel}><option value="All">All</option>{METROS.map(s => <option key={s}>{s}</option>)}</select></F>
      <F label="Tier"><select value={filters.tier} onChange={e => setFilters(p => ({ ...p, tier: e.target.value }))} style={sel}><option value="All">All</option>{TIERS.map(t => <option key={t}>Tier {t}</option>)}</select></F>
      <F label="Sort"><select value={sortBy} onChange={e => setSortBy(e.target.value)} style={sel}><option value="tier">Tier</option><option value="revenue">Revenue</option><option value="years">Years</option><option value="analog">Analog Score</option></select></F>
      {(filters.vertical !== "All" || filters.metro !== "All" || filters.tier !== "All" || filters.searchText) && (
        <button onClick={() => setFilters({ vertical: "All", metro: "All", tier: "All", searchText: "" })} style={{ background: "transparent", border: "1px solid #8B2500", color: "#ff6b47", borderRadius: 6, padding: "8px 14px", fontSize: 12, cursor: "pointer", fontFamily: "'Barlow',sans-serif", fontWeight: 600 }}>Clear</button>
      )}
    </div>

    <div style={{ display: "flex", minHeight: "calc(100vh - 240px)" }}>
      <div style={{ flex: selectedTarget ? "0 0 460px" : 1, overflow: "auto", maxHeight: "calc(100vh - 240px)" }}>
        {filtered.length === 0 && <div style={{ padding: 48, textAlign: "center", color: "#555" }}><div style={{ fontSize: 32, marginBottom: 8 }}>∅</div><div>No targets match filters</div></div>}
        {filtered.map(t => (
          <div key={t.id} onClick={() => setSelectedTarget(selectedTarget?.id === t.id ? null : t)} style={{
            padding: "14px 24px", borderBottom: "1px solid #141414", cursor: "pointer",
            background: selectedTarget?.id === t.id ? "rgba(21,71,51,0.15)" : "transparent",
            borderLeft: selectedTarget?.id === t.id ? "3px solid #FEE123" : "3px solid transparent",
            transition: "all 0.15s"
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 4 }}>
                  <span style={{ fontSize: 10, fontWeight: 800, color: t.tier === "A" ? "#000" : t.tier === "B" ? "#fff" : "#ccc", background: tierColor[t.tier], padding: "2px 8px", borderRadius: 4, letterSpacing: 1 }}>TIER {t.tier}</span>
                  <span style={{ fontSize: 10, background: "#154733", color: "#8fdfb4", padding: "2px 8px", borderRadius: 4, fontWeight: 600 }}>{t.vertical}</span>
                </div>
                <div style={{ fontSize: 14, fontWeight: 700, color: "#fff", marginBottom: 2 }}>{t.company}</div>
                <div style={{ fontSize: 11, color: "#777" }}>{t.location} · Est. {t.founded} ({t.yearsInBusiness} yrs) · {t.estRevenue}</div>
                <div style={{ fontSize: 11, color: t.owners.includes("Research needed") ? "#555" : "#FEE123", marginTop: 2, fontWeight: t.owners.includes("Research needed") ? 400 : 600 }}>
                  {t.owners.includes("Research needed") ? "Owner: Research needed" : "Owner: " + t.owners.split("—")[0].split("(")[0].trim()}
                </div>
              </div>
              <div style={{ textAlign: "right", flexShrink: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: "#FEE123" }}>Analog {t.analogScore}/10</div>
                <div style={{ fontSize: 10, color: "#777" }}>⭐ {t.googleRating} ({t.reviewCount})</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {selectedTarget && (
        <div style={{ flex: 1, borderLeft: "1px solid #1a1a1a", overflow: "auto", maxHeight: "calc(100vh - 240px)", background: "#080808" }}>
          <div style={{ padding: 24 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 20 }}>
              <div>
                <div style={{ display: "flex", gap: 6, marginBottom: 8, flexWrap: "wrap" }}>
                  <span style={{ fontSize: 11, fontWeight: 800, color: selectedTarget.tier === "A" ? "#000" : "#fff", background: tierColor[selectedTarget.tier], padding: "3px 10px", borderRadius: 4, letterSpacing: 1 }}>TIER {selectedTarget.tier}</span>
                  <span style={{ fontSize: 11, background: "#154733", color: "#8fdfb4", padding: "3px 10px", borderRadius: 4, fontWeight: 600 }}>{selectedTarget.vertical}</span>
                </div>
                <h2 style={{ fontSize: 22, color: "#FEE123", fontWeight: 800, marginBottom: 2 }}>{selectedTarget.company}</h2>
                <div style={{ fontSize: 13, color: "#888" }}>{selectedTarget.location} · Founded {selectedTarget.founded}</div>
                {selectedTarget.website && selectedTarget.website.startsWith("http") && (
                  <div onClick={() => window.open(selectedTarget.website, "_blank")} style={{ fontSize: 12, color: "#1b8a5a", textDecoration: "underline", display: "inline-block", marginTop: 4, cursor: "pointer" }}>{selectedTarget.website.replace("https://", "").replace("http://", "").replace(/\/$/, "")} ↗</div>
                )}
              </div>
              <button onClick={() => setSelectedTarget(null)} style={{ background: "#111", border: "1px solid #2a2a2a", color: "#777", borderRadius: 6, padding: "6px 12px", cursor: "pointer", fontSize: 12, fontFamily: "'Barlow',sans-serif", height: 32 }}>✕</button>
            </div>

            {selectedTarget.evaluation && (
              <div style={{ background: "rgba(254,225,35,0.04)", border: "1px solid rgba(254,225,35,0.12)", borderRadius: 10, padding: 18, marginBottom: 20 }}>
                <div style={{ fontSize: 13, color: "#ccc", lineHeight: 1.8 }}>{selectedTarget.evaluation}</div>
              </div>
            )}
            <Sec title="Owner / Decision Maker" color="#FEE123">
              {(selectedTarget.owners.includes("Research needed") || selectedTarget.owners.includes("Not publicly")) ? (
                <div style={{ fontSize: 13, color: "#8B2500", padding: "8px 0" }}>Owner research needed — check OR/WA Secretary of State</div>
              ) : (
                <div>
                  {(() => {
                    const raw = selectedTarget.owners;
                    // Extract CCB holder before stripping
                    const ccbMatch = raw.match(/CCB[^:]*:\s*([^.]+)/i);
                    const cleaned = raw
                      .replace(/\s*—\s*(3rd generation|2nd generation|Klink family|Cray family|sisters|family|per customer reviews).*$/i, "")
                      .replace(/\.\s*CCB.*$/, "")
                      .replace(/\.\s*Parent entity.*$/, "")
                      .replace(/\.\s*Legal entity.*$/, "")
                      .replace(/\.\s*PHCC.*$/, "")
                      .replace(/\.\s*Check.*$/, "")
                      .replace(/\.\s*Manager:.*$/, "")
                      .replace(/\.\s*BBB does not.*$/, "")
                      .replace(/\.\s*75\+.*$/, "")
                      .replace(/\s*—\s*but ACQUIRED.*$/, "");
                    const parts = cleaned.split(/,\s*(?=[A-Z])|\s+&\s+(?=[A-Z])/);
                    const rows = parts.map((person, i) => {
                      let trimmed = person.trim();
                      if (!trimmed || trimmed.length < 3) return null;
                      const titleMatch = trimmed.match(/\(([^)]+)\)/);
                      let title = titleMatch ? titleMatch[1].replace(/\s*—\s*per.*$/i, "").replace(/\s*per\s+.*$/i, "").trim() : "";
                      let name = trimmed.replace(/\s*\([^)]*\)/g, "").trim();
                      if (name.startsWith("but ") || name.startsWith("per ") || name.startsWith("Previously") || name.startsWith("Fourth") || name.startsWith("Research") || name.startsWith("The Gladow")) return null;
                      if (!name) return null;
                      return (
                        <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: "1px solid #1a1a1a" }}>
                          <div style={{ fontSize: 15, color: "#FEE123", fontWeight: 600 }}>{name}</div>
                          {title && <div style={{ fontSize: 14, color: "#1b8a5a", fontWeight: 600 }}>{title}</div>}
                        </div>
                      );
                    });
                    // Add CCB holders as separate rows
                    const ccbHolderMatch = raw.match(/CCB license holders?:\s*([^.]+)/i);
                    const ccbOwnerMatch = raw.match(/CCB license owner:\s*([^.]+)/i);
                    const ccbNames = ccbHolderMatch ? ccbHolderMatch[1].split(/,\s*/) : ccbOwnerMatch ? ccbOwnerMatch[1].split(/,\s*/) : [];
                    ccbNames.forEach((name, idx) => {
                      const n = name.trim();
                      if (n) rows.push(
                        <div key={"ccb"+idx} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: "1px solid #1a1a1a" }}>
                          <div style={{ fontSize: 15, color: "#FEE123", fontWeight: 600 }}>{n}</div>
                          <div style={{ fontSize: 14, color: "#1b8a5a", fontWeight: 600 }}>CCB License Holder</div>
                        </div>
                      );
                    });
                    // Add CCB license number if in data
                    if (selectedTarget.ccb && selectedTarget.ccb !== "Research needed") {
                      rows.push(
                        <div key="ccbnum" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: "1px solid #1a1a1a" }}>
                          <div style={{ fontSize: 13, color: "#888" }}>CCB #{selectedTarget.ccb}</div>
                          <div style={{ fontSize: 14, color: "#1b8a5a", fontWeight: 600 }}>OR Contractor License</div>
                        </div>
                      );
                    }
                    return rows;
                  })()}
                </div>
              )}
            </Sec>
            <Sec title="Contact Information" color="#1b8a5a">
              <Row l="Address" v={selectedTarget.address} gold />
              <Row l="Website" v={selectedTarget.website} />
              <div style={{ display: "flex", gap: 8, marginTop: 8, flexWrap: "wrap" }}>
                {selectedTarget.website && selectedTarget.website.startsWith("http") && (
                  <div onClick={() => window.open(selectedTarget.website, "_blank")} style={{ display: "inline-flex", alignItems: "center", gap: 6, background: "#111", border: "1px solid #2a2a2a", color: "#ccc", padding: "7px 14px", borderRadius: 6, fontSize: 12, fontWeight: 600, cursor: "pointer" }}>🌐 Open Website →</div>
                )}
                {selectedTarget.linkedIn && (
                  <div onClick={() => window.open(selectedTarget.linkedIn, "_blank")} style={{ display: "inline-flex", alignItems: "center", gap: 8, background: "#154733", border: "1px solid #1b8a5a", color: "#FEE123", padding: "7px 14px", borderRadius: 6, fontSize: 12, fontWeight: 700, cursor: "pointer" }}>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="#FEE123"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
                    Owner LinkedIn →
                  </div>
                )}
              </div>
            </Sec>
            <Sec title="Financial Estimates" color="#1b8a5a">
              <Row l="Est. Revenue" v={selectedTarget.estRevenue} />
              <Row l="Google Rating" v={`⭐ ${selectedTarget.googleRating} (${selectedTarget.reviewCount} reviews)`} />
            </Sec>
            <Sec title="Analog Score" color="#FEE123">
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <div style={{ display: "flex", gap: 3 }}>{Array.from({ length: 10 }).map((_, i) => <div key={i} style={{ width: 24, height: 8, borderRadius: 2, background: i < selectedTarget.analogScore ? "#FEE123" : "#1a1a1a" }} />)}</div>
                <span style={{ fontSize: 20, color: "#FEE123", fontWeight: 800 }}>{selectedTarget.analogScore}/10</span>
              </div>
              <div style={{ fontSize: 11, color: "#555", marginTop: 4 }}>Higher = more analog ops = greater post-acquisition margin expansion</div>
            </Sec>

          </div>
        </div>
      )}
    </div>
  </div>;
}
