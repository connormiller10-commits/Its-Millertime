import React, { useState } from 'react';

const AGENT_SYSTEM = `You are a high-speed M&A research agent for WTD Ventures. You research service business acquisition targets (HVAC, plumbing, electrical) in Oregon/SW Washington.

CRITICAL: Respond ONLY with valid JSON. No preamble, no markdown, no backticks. Output a JSON array of target objects.

For each company, search the web and return:
{"company":"Full Name","vertical":"HVAC","location":"City, OR","state":"OR","metro":"Portland Metro|SW Washington|Salem / Willamette Valley|Eugene / Springfield|Bend / Central Oregon","founded":1965,"yearsInBusiness":61,"owners":"Name (Title). CCB license holders: Name","website":"https://...","estRevenue":"$2M-$5M","estRevenueNum":3500000,"googleRating":4.5,"analogScore":7,"ccb":"12345","evaluation":"2-3 sentence investment thesis.","notes":"Key facts under 120 chars.","tier":"A"}

Rules:
- Search web for EACH company: website, BBB, Google reviews, BuildZoom for CCB employees
- owners: Use "Research needed" if unverifiable. NEVER fabricate names.
- ccb: Use "Research needed" if unknown. Oregon CCB numbers only.
- analogScore: 0-10 (10=no website/phone only, 5=basic website, 0=fully modern)
- tier: A=verified owner+20yr+analog5+ | B=partial data or owner not ready | C=weak target
- evaluation: Be direct and opinionated. "Worth a letter" or "Pass" — no hedging.
- EXCLUDE PE-acquired: Sunset Heating(Apex), Specialty Heating(SEER), Climate Control(SEER), First Call(SEER), Sun Glow(competitor)
- When asked for a market sweep, search for established companies in that market and return all qualifying targets.
- Output ONLY the JSON array. Nothing else.`;

export default function ResearchAgent({ onTargetsFound }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(null);

  const run = async () => {
    if (!input.trim() || loading) return;
    const userMsg = input.trim();
    setInput("");
    setMessages(prev => [...prev, { role: "user", text: userMsg }]);
    setLoading(true);
    setProgress({ current: 0, total: 0, status: "Analyzing request..." });

    try {
      // Phase 1: Decompose into search queries
      const planRes = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 2000,
          system: `You decompose M&A research requests into web search queries. Output ONLY a JSON array of search query strings. No preamble, no markdown. Generate 1-3 targeted search queries per company. For market sweeps ("find HVAC in Medford"), generate 5-15 queries covering different search angles (BBB, "oldest", "established", "family owned", state contractor lists). Max 30 queries.`,
          messages: [{ role: "user", content: userMsg }],
        }),
      });
      const planData = await planRes.json();
      const planText = (planData.content || []).filter(c => c.type === "text").map(c => c.text).join("");
      let queries;
      try { queries = JSON.parse(planText.replace(/```json|```/g, "").trim()); } catch { queries = [userMsg]; }
      if (!Array.isArray(queries)) queries = [userMsg];

      setProgress({ current: 0, total: queries.length, status: `Launching ${queries.length} parallel searches...` });

      // Phase 2: Parallel web searches in batches of 5
      const batchSize = 5;
      const allResults = [];
      for (let i = 0; i < queries.length; i += batchSize) {
        const batch = queries.slice(i, i + batchSize);
        const promises = batch.map(q =>
          fetch("https://api.anthropic.com/v1/messages", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              model: "claude-sonnet-4-20250514",
              max_tokens: 1000,
              system: "Search the web and return ALL relevant facts about this service company for M&A research: owner names, CCB license number, founded year, revenue estimate, employee count, Google rating, services offered, address, phone, website URL. Output raw facts only. Be thorough.",
              messages: [{ role: "user", content: q }],
              tools: [{ type: "web_search_20250305", name: "web_search" }],
            }),
          }).then(r => r.json()).then(d => {
            const text = (d.content || []).filter(c => c.type === "text").map(c => c.text).join("\n");
            return { query: q, facts: text };
          }).catch(e => ({ query: q, facts: "Search failed: " + e.message }))
        );
        const results = await Promise.all(promises);
        allResults.push(...results);
        setProgress({
          current: Math.min(i + batchSize, queries.length),
          total: queries.length,
          status: `Searched ${Math.min(i + batchSize, queries.length)} of ${queries.length}...`
        });
      }

      // Phase 3: Synthesize into structured targets
      setProgress({ current: queries.length, total: queries.length, status: "Building target cards..." });
      const factsBlock = allResults.map(r => `--- [${r.query}] ---\n${r.facts}`).join("\n\n");

      const synthRes = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 8000,
          system: AGENT_SYSTEM,
          messages: [{ role: "user", content: `Based on these research results, output a JSON array of acquisition target objects.\n\nOriginal request: "${userMsg}"\n\nResearch:\n${factsBlock}` }],
        }),
      });
      const synthData = await synthRes.json();
      const synthText = (synthData.content || []).filter(c => c.type === "text").map(c => c.text).join("\n");

      let displayText;
      let parsedTargets = null;
      try {
        parsedTargets = JSON.parse(synthText.replace(/```json|```/g, "").trim());
        displayText = `✅ Found ${parsedTargets.length} targets:\n\n` + parsedTargets.map(t =>
          `★ ${t.company} (${t.location})\n  ${t.vertical} | Founded: ${t.founded} | Analog: ${t.analogScore}/10 | Tier ${t.tier}\n  Owner: ${t.owners}\n  CCB: ${t.ccb} | Rev: ${t.estRevenue}\n  → ${t.evaluation}`
        ).join("\n\n");
      } catch {
        displayText = synthText;
      }

      setMessages(prev => [...prev, { role: "assistant", text: displayText, targets: parsedTargets }]);

      // Callback to parent with discovered targets
      if (parsedTargets && onTargetsFound) {
        onTargetsFound(parsedTargets);
      }
    } catch (err) {
      setMessages(prev => [...prev, { role: "assistant", text: "Error: " + err.message }]);
    }
    setLoading(false);
    setProgress(null);
  };

  return (
    <div style={{ margin: "0 24px 16px", background: "#0a0a0a", border: "1px solid #1b8a5a", borderRadius: 12, overflow: "hidden" }}>
      <div style={{ padding: "14px 16px", background: "linear-gradient(180deg, #154733, #0d2e22)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <div style={{ fontFamily: "'Rajdhani',sans-serif", fontSize: 15, color: "#FEE123", fontWeight: 700, letterSpacing: 1 }}>AI RESEARCH AGENT</div>
          <div style={{ fontSize: 11, color: "#1b8a5a" }}>Parallel web search — researches up to 100 companies at once</div>
        </div>
      </div>

      <div style={{ maxHeight: 500, overflow: "auto", padding: 16 }} id="agent-scroll">
        {messages.length === 0 && (
          <div style={{ textAlign: "center", padding: "24px 16px" }}>
            <div style={{ fontSize: 13, color: "#555", marginBottom: 16 }}>Research any company, market, or run a full sweep:</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6, justifyContent: "center" }}>
              {[
                "Find all HVAC companies in Medford, Oregon",
                "Research Bend Heating, Mountain View Heating, and Severson Plumbing",
                "Find plumbing and electrical targets in Eugene",
                "Look up owners and CCB for Damar Heating, Watts Heating, Roth Home",
                "Find established service businesses in Klamath Falls",
                "Research the top 10 oldest HVAC companies in Salem"
              ].map((ex, i) => (
                <div key={i} onClick={() => setInput(ex)} style={{
                  background: "#111", border: "1px solid #1a1a1a", borderRadius: 6,
                  padding: "8px 14px", fontSize: 12, color: "#888", cursor: "pointer",
                  transition: "all 0.15s"
                }}>{ex}</div>
              ))}
            </div>
          </div>
        )}

        {messages.map((msg, i) => (
          <div key={i} style={{ marginBottom: 16, display: "flex", flexDirection: "column", alignItems: msg.role === "user" ? "flex-end" : "flex-start" }}>
            <div style={{
              maxWidth: "90%", padding: "12px 16px", borderRadius: 10,
              background: msg.role === "user" ? "rgba(254,225,35,0.08)" : "#111",
              border: msg.role === "user" ? "1px solid rgba(254,225,35,0.2)" : "1px solid #1a1a1a",
              fontSize: 13, color: "#ccc", lineHeight: 1.8, whiteSpace: "pre-wrap"
            }}>
              {msg.text}
            </div>
            {msg.targets && (
              <div style={{ marginTop: 8, fontSize: 11, color: "#1b8a5a", fontWeight: 600 }}>
                ✓ {msg.targets.length} targets ready — added to pipeline
              </div>
            )}
          </div>
        ))}

        {loading && progress && (
          <div style={{ padding: "12px 0" }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
              <span style={{ fontSize: 12, color: "#1b8a5a", fontWeight: 600 }}>{progress.status}</span>
              {progress.total > 0 && (
                <span style={{ fontSize: 11, color: "#888" }}>{progress.current}/{progress.total}</span>
              )}
            </div>
            {progress.total > 0 && (
              <div style={{ background: "#1a1a1a", borderRadius: 4, height: 8, overflow: "hidden" }}>
                <div style={{
                  background: "linear-gradient(90deg, #154733, #1b8a5a, #FEE123)",
                  height: "100%", borderRadius: 4,
                  width: `${(progress.current / progress.total) * 100}%`,
                  transition: "width 0.3s"
                }} />
              </div>
            )}
          </div>
        )}
      </div>

      <div style={{ padding: "12px 16px", borderTop: "1px solid #1a1a1a", display: "flex", gap: 8 }}>
        <input
          type="text" value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === "Enter" && run()}
          placeholder="Research companies, markets, or CCB lookups..."
          style={{
            flex: 1, background: "#111", border: "1px solid #2a2a2a", borderRadius: 8,
            color: "#e0e0e0", padding: "12px 14px", fontSize: 13,
            fontFamily: "'Barlow',sans-serif", outline: "none"
          }}
        />
        <button onClick={run} disabled={loading} style={{
          background: loading ? "#1a1a1a" : "linear-gradient(180deg, #154733, #0d2e22)",
          color: loading ? "#555" : "#FEE123",
          border: "1px solid #1b8a5a",
          borderRadius: 8, padding: "12px 20px", fontSize: 12, fontWeight: 700,
          fontFamily: "'Rajdhani',sans-serif",
          cursor: loading ? "default" : "pointer",
          letterSpacing: 1.5, textTransform: "uppercase"
        }}>RESEARCH</button>
      </div>
    </div>
  );
}
