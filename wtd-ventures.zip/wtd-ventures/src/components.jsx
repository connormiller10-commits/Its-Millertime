import React from 'react';

export function Logo() {
  return (
    <svg width="40" height="40" viewBox="0 0 60 60">
      <rect width="60" height="60" rx="12" fill="#154733" />
      <path d="M10 42 L18 18 L24 36 L30 18 L36 36 L42 18 L50 42" stroke="#FEE123" strokeWidth="5" fill="none" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M30 38 L30 22 L38 30 Z" fill="#FEE123" opacity="0.3" />
    </svg>
  );
}

export function Card({ children, accent }) {
  return (
    <div style={{
      background: "#0a0a0a",
      border: "1px solid #1a1a1a",
      borderRadius: 10,
      padding: 20,
      marginBottom: 16,
      borderLeft: accent ? `3px solid ${accent}` : undefined
    }}>
      {children}
    </div>
  );
}

export function Sec({ title, children, color = "#FEE123" }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <div style={{ fontFamily: "'Rajdhani',sans-serif", fontSize: 11, letterSpacing: 2.5, textTransform: "uppercase", color, fontWeight: 700, marginBottom: 8 }}>{title}</div>
      {children}
    </div>
  );
}

export function Row({ l, v, gold }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", borderBottom: "1px solid #111" }}>
      <span style={{ fontSize: 12, color: "#777" }}>{l}</span>
      <span style={{ fontSize: 12, color: gold ? "#FEE123" : "#ccc", fontWeight: gold ? 600 : 400, textAlign: "right", maxWidth: "65%" }}>{v}</span>
    </div>
  );
}

export function OutreachCard({ title, subtitle, badge, accent, casual, pe, local }) {
  const [tone, setTone] = React.useState("casual");
  const tones = [
    { id: "casual", label: "Casual" },
    { id: "local", label: "Local" },
    { id: "pe", label: "PE" },
  ];
  const content = { casual, pe, local };
  const toneColors = { casual: "#FEE123", local: "#1b8a5a", pe: "#2563eb" };
  return (
    <div style={{ background: "#0a0a0a", border: "1px solid #1a1a1a", borderRadius: 10, padding: 20, marginBottom: 16, borderLeft: `3px solid ${accent || "#FEE123"}` }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
        <div>
          <div style={{ fontFamily: "'Rajdhani',sans-serif", fontSize: 17, color: accent || "#FEE123", fontWeight: 700, letterSpacing: 0.5 }}>{title}</div>
          <div style={{ fontSize: 11, color: "#888" }}>{subtitle}</div>
        </div>
        {badge && <div style={{ fontSize: 10, background: "rgba(254,225,35,0.1)", color: "#FEE123", padding: "4px 10px", borderRadius: 4, fontWeight: 600 }}>{badge}</div>}
      </div>
      <div style={{ display: "flex", gap: 4, marginBottom: 12 }}>
        {tones.map(t => (
          <button key={t.id} onClick={() => setTone(t.id)} style={{
            background: tone === t.id ? `${toneColors[t.id]}18` : "#111",
            color: tone === t.id ? toneColors[t.id] : "#555",
            border: tone === t.id ? `1px solid ${toneColors[t.id]}40` : "1px solid #1a1a1a",
            borderRadius: 6, padding: "6px 16px", fontSize: 11, fontWeight: 700,
            fontFamily: "'Rajdhani',sans-serif", cursor: "pointer", letterSpacing: 1.5, textTransform: "uppercase",
            transition: "all 0.15s"
          }}>{t.label}</button>
        ))}
      </div>
      <div style={{ background: "#111", borderRadius: 8, padding: 20, borderTop: `2px solid ${toneColors[tone]}30` }}>
        <div style={{ fontSize: 13, color: "#ccc", lineHeight: 2, whiteSpace: "pre-wrap" }}>{content[tone]}</div>
      </div>
    </div>
  );
}
